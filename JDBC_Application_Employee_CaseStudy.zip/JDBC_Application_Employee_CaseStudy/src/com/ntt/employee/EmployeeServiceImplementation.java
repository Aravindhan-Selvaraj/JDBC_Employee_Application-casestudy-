package com.ntt.employee;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import org.junit.Test;

public class EmployeeServiceImplementation implements EmployeeService
{

	@Override
	public int create(Connection con,EmployeeDomain obj) throws Exception 
	{		
		
//		System.out.println("Create Method");
		PreparedStatement stmt=con.prepareStatement("insert into EmployeeDetails values (sequence_1.nextval,?,?,to_date(?,'DD/MM/YYYY'),?,to_date(?,'DD/MM/YYYY'))"); 
		stmt.setString(1,obj.getEmployeeName());
		stmt.setString(2,obj.getEmployeeAddress());
		stmt.setString(3, new SimpleDateFormat("dd-MM-yyyy").format(obj.getDateOfJoining()));
		stmt.setInt(4,obj.getExperience());
		stmt.setString(5, new SimpleDateFormat("dd-MM-yyyy").format(obj.getDateOfBirth()));
		int i=stmt.executeUpdate();  
		System.out.println(i+" records inserted into EmployeeDetails Table ");  
		return i;
	     
				
	}

	@Override
	public int read(Connection con,int empId) throws Exception 
	{
		// TODO Auto-generated method stub
		//System.out.println("Read Method");
		PreparedStatement stmt=con.prepareStatement("select * from EmployeeDetails where employeeId =?"); 
		stmt.setInt(1,empId);
		ResultSet rs=stmt.executeQuery();
		int a=0;
		while(rs.next())   
		{
				a=rs.getInt(1);
				System.out.println("Employee Name :  "+rs.getString(2));
				System.out.println("Employee Address :  "+rs.getString(3));
				System.out.println("Date Of Joining :  "+rs.getString(4));
				System.out.println("Experience :  "+rs.getString(5));
				System.out.println("Date Of Birth :  "+rs.getString(6));
				break;
			
		}
		if(a==empId)
		{}
		else
		{
			System.out.println("Employee not found for this id "+empId);
			a=1;
		}
	
		return a;
		
	}

	@Override
	public void update(Connection con,EmployeeDomain obj,int empId) throws Exception 
	{
		// TODO Auto-generated method stub
		PreparedStatement stmt=con.prepareStatement("UPDATE EmployeeDetails SET EMPLOYEENAME=?,EMPLOYEEADDRESS=?,DATEOFJOINING=to_date(?,'DD/MM/YYYY'),EXPERIENCE=?,DATEOFBIRTH=to_date(?,'DD/MM/YYYY') WHERE EMPLOYEEID=?"); 
		stmt.setString(1,obj.getEmployeeName());
		stmt.setString(2,obj.getEmployeeAddress());
		stmt.setString(3, new SimpleDateFormat("dd-MM-yyyy").format(obj.getDateOfJoining()));
		stmt.setInt(4,obj.getExperience());
		stmt.setString(5, new SimpleDateFormat("dd-MM-yyyy").format(obj.getDateOfBirth()));
		stmt.setInt(6,empId);
		int i=stmt.executeUpdate();  
		System.out.println(i+" records update  inthe EmployeeDetails Table ");  
		

		
	}

	@Override
	public void delete(Connection con,int empId) throws Exception 
	{
		// TODO Auto-generated method stub
		PreparedStatement stmt=con.prepareStatement("DELETE FROM EmployeeDetails WHERE employeeId = ?"); 
		stmt.setInt(1,empId);
		int i=stmt.executeUpdate();  
		System.out.println(i+" record deleted  inthe EmployeeDetails Table ");  
		
	}
	
	



	
	
}



