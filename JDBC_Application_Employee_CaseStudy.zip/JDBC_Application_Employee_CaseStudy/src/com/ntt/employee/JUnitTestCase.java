package com.ntt.employee;

import static org.junit.Assert.*;

import org.junit.Test;

public class JUnitTestCase {

	@Test
	public void InsertTest() 
	{
		int i=EmployeeDriver.insertCheck;
		assertEquals(1,i);
	}

}
