package com.ntt.employee;

import java.sql.Connection;

public interface EmployeeService 
{
	public int  create(Connection con,EmployeeDomain obj) throws Exception;
	public int  read(Connection con,int empId) throws Exception;
	public void  update(Connection con,EmployeeDomain obj,int empId) throws Exception;
	public void  delete(Connection con,int empId) throws Exception;
	//public void InsertOperationtest(Connection con, EmployeeDomain obj);

}
