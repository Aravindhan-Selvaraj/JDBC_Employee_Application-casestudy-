package com.ntt.employee;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.Properties;
import java.util.Scanner;

public class EmployeeDriver {

	public static int insertCheck=0;
	public static void main(String[] args) throws Exception 
	{
		
		Properties prop=new Properties();
		FileInputStream in=new FileInputStream("jdbc.properties");
		prop.load(in);
		String driver=prop.getProperty("driver");
		String conurl=prop.getProperty("url");
		String user=prop.getProperty("user");
		String password=prop.getProperty("password");
		//System.out.println(driver);
		Class.forName(driver);
		Connection con=DriverManager.getConnection(conurl,user,password);			
		String qwe=null;
		
		System.out.println("Welcome to JDBC Application on Employee domain");
		System.out.println("----------------------------------------------");
		
		do
		{
		System.out.println("Choose the Operation to perform");
		System.out.println("1 for Create / Insert employee details");
		System.out.println("2 for Read / Fetch employee details");
		System.out.println("3 for Update  employee details");
		System.out.println("4 for Delete employee details");
		System.out.println("");
		System.out.print("Enter the Operation Number : ");
		Scanner sc= new Scanner(System.in);   
		int operationNumber= sc.nextInt();    
		
		EmployeeDomain obj=new EmployeeDomain();
		EmployeeService obj1=new EmployeeServiceImplementation();
		//JUnitTestCase o=new JUnitTestCase();
		
		if(operationNumber==1)
		{
			
			System.out.println("You have entered create / insert operation: "+operationNumber);
			System.out.println("Enter the Employee Name :  ");
			Scanner sc1= new Scanner(System.in);
			obj.setEmployeeName(sc1.nextLine());
			System.out.println("Enter the Employee Address :  ");
			Scanner sc2= new Scanner(System.in);
			obj.setEmployeeAddress(sc2.nextLine());
			System.out.println("Enter the Date Of Joining (dd/MM/yyyy) :  ");	
			Scanner sc3= new Scanner(System.in);
			obj.setDateOfJoining(new SimpleDateFormat("dd/MM/yyyy").parse(sc3.nextLine()));
			System.out.println("Enter the Experience :  ");
			Scanner sc4= new Scanner(System.in);
			obj.setExperience(sc4.nextInt());
			System.out.println("Enter the Date Of Birth (dd/MM/yyyy) :  ");
			Scanner sc5= new Scanner(System.in); 
			obj.setDateOfBirth(new SimpleDateFormat("dd/MM/yyyy").parse(sc5.nextLine()));
			insertCheck=obj1.create(con,obj);
			
			
			
		}
		else if(operationNumber==2)
		{
			System.out.println("You have entered read / Fetch operation: "+operationNumber);
			System.out.print("Enter the  EmployeeId  : ");
			Scanner s= new Scanner(System.in);   
			int empId= s.nextInt();
			obj1.read(con,empId);
			
		}
		else if(operationNumber==3)
		{
			System.out.println("You have entered Update operation: "+operationNumber);
			System.out.println("Enter the  EmployeeId  : ");
			Scanner s= new Scanner(System.in);   
			int empId= s.nextInt();
			int a=obj1.read(con,empId);
			System.out.println("");
			if(a==1) {}
			else {
			System.out.println("enter the details which you want to update");
			System.out.println("Enter the Employee Name :  ");
			Scanner sc1= new Scanner(System.in);
			obj.setEmployeeName(sc1.nextLine());
			System.out.println("Enter the Employee Address :  ");
			Scanner sc2= new Scanner(System.in);
			obj.setEmployeeAddress(sc2.nextLine());
			System.out.println("Enter the Date Of Joining (dd/MM/yyyy) :  ");	
			Scanner sc3= new Scanner(System.in);
			obj.setDateOfJoining(new SimpleDateFormat("dd/MM/yyyy").parse(sc3.nextLine()));
			System.out.println("Enter the Experience :  ");
			Scanner sc4= new Scanner(System.in);
			obj.setExperience(sc4.nextInt());
			System.out.println("Enter the Date Of Birth (dd/MM/yyyy) :  ");
			Scanner sc5= new Scanner(System.in); 
			obj.setDateOfBirth(new SimpleDateFormat("dd/MM/yyyy").parse(sc5.nextLine()));
			obj1.update(con,obj,empId);
			}
		}
		else if(operationNumber==4)
		{
			System.out.println("You have entered Delete Operation: "+operationNumber);
			System.out.println("Enter the  EmployeeId  : ");
			Scanner s= new Scanner(System.in);   
			int empId= s.nextInt();
			int a=obj1.read(con,empId);
			if(a==1) {}
			else 
			{
				obj1.delete(con,empId);
			}
		}
		else
		{
			System.out.println("Kindly enter the correct operation Number");
		}
		System.out.println("");
		System.out.println("Do you want to continue");
		System.out.println("Press Y to continue and  N to exit");
		Scanner scc= new Scanner(System.in);   
		qwe= scc.nextLine(); 
		if(qwe.equalsIgnoreCase("N") || qwe.equalsIgnoreCase("n")) {System.out.println("Thank You");}
		}while(qwe.equalsIgnoreCase("Y") || qwe.equalsIgnoreCase("y"));
		

	}

}
